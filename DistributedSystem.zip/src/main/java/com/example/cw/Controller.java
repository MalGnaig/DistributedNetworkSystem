package com.example.cw;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Controller {

    private static int cport;
    private int duplicates;
    private int timeout;
    private int rebalancePeriod;

    private static int cport;
    private static int replication;
    private static int timeout;
    private static int rebalancePeriod;
    private static ServerSocket server;
    private static boolean lock;
    private static int rebalanceResponses;
    private AtomicLong lastRebalanceTime = new AtomicLong();


    public Controller(int cport, int duplicates, int timeout, int rebalancePeriod) {
        this.cport = cport;
        this.duplicates = duplicates;
        this.timeout = timeout;
        this.rebalancePeriod = rebalancePeriod;
    }

    public static void main(String[] args) {
        while (true) {
            // Listen to messages


        }
    }
}
